#ifndef _KINEMATICS_H
#define _KINEMATICS_H


class kinematics_c {
  public:

    // What variables do you need?
    // What is the appropriate type?
    // ...

    // Function Prototypes
    kinematics_c();   // constructor 
    void update();    // update kinematics
    
    
}; // End of class definition.


kinematics_c::kinematics_c() {
  // ...  
} // end of constructor.

// Routine to execute the update to
// kinematics 
void kinematics_c::update() {
  // ...
}


#endif
